function postBookData() {
    $.post("postData.php",
    {
        title: $('#title').val(),
        tpages: $('#tpages').val(),
        aname: $('#aname').val(),
        emailadd: $('#emailadd').val(),
        pdate: $('#pdate').val(),
        bgenre: $('#bgenre').val() 
    },
    function(data, status){
        $('#data').html(data);
    });
    return false;
}

var table = "";

function getDataButton(){
    if ( $.fn.dataTable.isDataTable( '#example' ) ) {
        table.destroy();
    }
    $('#example').html(
    "<thead>" +
    "<tr>" +
    "<th>Book Id</th>" +
    "<th>Title</th>" +
    "<th>Total pages</th>" +
    "<th>Author Name</th>" +
    "<th>Author Email</th>" +
    "<th>Published Date</th>" +
    "<th>Genre</th>" +
    "</tr>" +
    "</thead>");
    table = $('#example').DataTable( {
        lengthMenu: [[5, 10, 25, -1], [5, 10, 25, "All"]],
        ajax: {
            url: 'getData.php',
            dataSrc: ''
        }
    } );
}

//Edit Data

$(document).ready(function() {
    $("#editVis").hide();
    selTitle = document.getElementById("titles");
    var titles = [];
    $.get("getTitles.php", function(data, status) {
        titles = JSON.parse(data);
        for( var i=0; i<titles.length; i++) {
            selTitle.options[selTitle.options.length] = new Option(titles[i],titles[i]);
        }
    });
	
});

function getEditData() {
    $.post("getEditData.php",
    {title : $("#titles").val()},
    function(data, status){
        detail = JSON.parse(data);
        $("#etpages").val(detail.total_pages);
        $("#eaname").val(detail.author_name);
        $("#eemailadd").val(detail.author_email);
        $("#epdate").val(detail.published_date);
        $("#ebgenre").val(detail.genre);
    });
	$("#editVis").show();
}

function editBookData() {
    $.post("editData.php",
    {
        title: $('#titles').val(),
        tpages: $('#etpages').val(),
        aname: $('#eaname').val(),
        emailadd: $('#eemailadd').val(),
        pdate: $('#epdate').val(),
        bgenre: $('#ebgenre').val() 
    },
    function(data, status){
        $('#data').html(data);
    });
    return false;
}

//Delete Data

function deleteBookData() {
    $.post("deleteData.php",
    {title : $("#titles").val()},
    function(data, status){
        $('#data').html(data);
    });
    return false;
}