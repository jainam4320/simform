<?php 
    $title = $tpages = $aname = $emailadd = $pdate = $bgenre =""; 

    function test_input($data)	{
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    if(!empty($_POST))	{
        $title = test_input($_POST["title"]);
        $tpages = test_input($_POST["tpages"]);
        $aname = test_input($_POST["aname"]);
        $emailadd = test_input($_POST["emailadd"]);
        $pdate = test_input($_POST["pdate"]);
        $bgenre = test_input($_POST["bgenre"]);
    }

    require 'dbconnection.php';

    try {  
        $sql = "SELECT * FROM book WHERE title=?";
        $smt = $conn->prepare($sql);
        $smt->bind_param("s", $title);
        $smt->execute();
        $result = $smt->get_result();
        if ($result->num_rows > 0) {
            $smt->close();
            throw new Exception("Duplicate entry with same title");
        }
        $smt = $conn->prepare("INSERT INTO book (title, total_pages, author_name, author_email, published_date, genre) VALUES (?,?,?,?,?,?)");
        $smt->bind_param("sissss", $title, $tpages, $aname, $emailadd, $pdate, $bgenre);
        $smt->execute();
        $smt->close();
        echo "<div class='alert alert-success alert-dismissible fade show text-center my-4' role='alert'>" .
             "Book data inserted successfully" .
             "<button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>" .
             "</div>";
    } catch(Exception $e) {
        $conn->rollback();
        echo "<div class='alert alert-danger alert-dismissible fade show text-center my-4' role='alert'>" .
             $e->getMessage() .
             "<button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>" .
             "</div>";
        throw $e;
    } finally {
        $conn->close();
    }
    
?>